Thanks for your purchase. 

to be able to compile this extension, you need to add the following ANEs to your project. https://github.com/myflashlab/common-dependencies-ANE
androidSupport.ane
overrideAir.ane

NOTICE: If you are targeting AIR SDK 24+ you might need the [permissionCheck.ane](https://github.com/myflashlab/PermissionCheck-ANE/) also.

if you have any question about how the extension works, please contact us through the 'issues' page on github.

Best Regards,
MyFlashLab Team